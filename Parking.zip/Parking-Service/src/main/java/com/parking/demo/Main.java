package com.parking.demo;

import java.util.Map;

public class Main {
	public static void main(String[] args) {
	Park park=new Park();
	OwnerDetails owner=new OwnerDetails("Bindu", "9481151309", "10:11");
	park.addCar(new OwnerDetails("Yashu","8288811761", "8:30"));
	park.addCar(new OwnerDetails("Ranju","8288811762", "9:00"));
	park.addCar(new OwnerDetails("Sprsh","8288811763", "10:00"));
	park.addCar(new OwnerDetails("Ashish","8288811748", "11:30"));
	park.addCar(new OwnerDetails("Sowmya","8288811758", "12:00"));
	park.addCar(new OwnerDetails("Deeksha","8288811668", "1:00"));
	park.addCar(new OwnerDetails("Pragnya","8288811768", "2:00"));
	park.addCar(new OwnerDetails("Bindu1","8288811788", "3:30"));
	park.addCar(new OwnerDetails("Bindu2","8288811798", "4:00"));
	park.addCar(new OwnerDetails("Bindu3","8299911768", "5:00"));
	park.addCar(new OwnerDetails("Bindu4","8299911768", "6:00"));
	park.addCar(owner);
	park.getAllCars();
	for(Map.Entry e
	: park.getAllCars() ) {
	System.out.println(e.getKey()+" " + e.getValue());
	}
	System.out.println(park.getCarById(owner.getId()));
	
	}


}
