package com.lambda.example;

public class MyThread implements Runnable{

	@Override
	public void run() {
		System.out.println("Executing");
		
	}

}
