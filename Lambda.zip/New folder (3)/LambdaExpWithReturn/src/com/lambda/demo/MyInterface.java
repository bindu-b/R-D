package com.lambda.demo;
@FunctionalInterface
public interface MyInterface {
	
	boolean test(int n1,int n2);

}
