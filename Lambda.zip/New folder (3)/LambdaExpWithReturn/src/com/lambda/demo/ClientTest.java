package com.lambda.demo;

public class ClientTest {

	public static void main(String[] args) {
		MyInterface myInterface=(n1,n2)-> n1>n2;
		System.out.println(myInterface.test(10, 20));
		System.out.println(myInterface.test(20, 10));
	}

}
