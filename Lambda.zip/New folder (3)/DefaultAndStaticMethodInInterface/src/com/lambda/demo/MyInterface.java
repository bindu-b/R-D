package com.lambda.demo;

import java.util.Collections;
import java.util.List;

import com.lambda.model.Student;
@FunctionalInterface
public interface MyInterface {
	
	public abstract Integer getMaxNum(List<Integer> intList);
	
	default public List<Student> sortStudents(List<Student> stuList){
		Collections.sort(stuList);
		return stuList;

	}
	
	public static void greet(String name)
	{
		System.out.println("Welcome:"+name);
	}
	
	

}
