package com.interf.demo;

public interface I2 {
	
	default public void display() {
		System.out.println("I2:Display");
	}

}
