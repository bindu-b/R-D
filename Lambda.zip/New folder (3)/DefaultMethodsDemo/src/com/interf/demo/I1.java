package com.interf.demo;

public interface I1 {
	default public void display() {
		System.out.println("I1:Display");
	}

}
