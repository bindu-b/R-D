package com.demo;
@FunctionalInterface
public interface MyInterface3 {
	
	void method3(String name,int age);

}
