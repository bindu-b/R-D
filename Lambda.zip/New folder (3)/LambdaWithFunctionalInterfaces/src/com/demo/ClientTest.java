package com.demo;

public class ClientTest {

	public static void main(String[] args) {
		MyInterface1 myInterface1=() ->
				System.out.println("This method executes using lambda..");
				
			
		
		myInterface1.method1();
		
		MyInterface2 myInterface2=(String name)->System.out.println("name:"+name);
		myInterface2.method2("Bindu");
		
		
		MyInterface3 myInterface3=(name,age)->System.out.println(name+age);
		myInterface3.method3("Bindu", 22);
	}
	

}
