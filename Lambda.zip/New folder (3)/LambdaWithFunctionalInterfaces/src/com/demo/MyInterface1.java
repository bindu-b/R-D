package com.demo;
@FunctionalInterface
public interface MyInterface1 {
	
	public abstract void method1();

}
