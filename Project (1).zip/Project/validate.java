package com.olx.validate
 
import java.io.IOException;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
/**
 * Servlet implementation class guru_register
 */
public class guru_register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String first_name = request.getParameter("fname");
		String first_name = request.getParameter("email");
		String phone = request.getParameter("phone");
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		
		
		
		if((fname.isEmpty() || email.isEmpty() || password.isEmpty() || phone.isEmpty())&& ((!password1.equals(password2)))) 
		{
			RequestDispatcher req = request.getRequestDispatcher("index.jsp");
			req.include(request, response);
		}
		
		else
		{
			RequestDispatcher req = request.getRequestDispatcher("tryagain.jsp");
			req.forward(request, response);
		}
	}
 
}