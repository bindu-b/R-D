package com.demo.mockito;

public class FuelTank {
	
	private int fuel;
	public int getFuel() {
		return fuel;
	}
	
	public void setFuel(int fuel) {
		this.fuel=fuel;
	}

}
