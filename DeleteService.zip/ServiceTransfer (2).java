package com.FileTransfer.FingTranser;
import java.io.*;
import java.nio.file.*;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class ServiceTransfer {
	
	@RequestMapping(value="/home")
	public String movefile() throws IOException
	{
		Path temp = Files.move
		        (Paths.get("C:\\Users\\sanbhatt\\fu\\b.txt"), 
		        Paths.get("D:\\dest\\a.txt"));
		 
		        if(temp != null)
		        {
		            System.out.println("File renamed and moved successfully");
		        }
		        else
		        {
		            System.out.println("Failed to move the file");
		        }
		         return "file transfered successfully";
	}

}
