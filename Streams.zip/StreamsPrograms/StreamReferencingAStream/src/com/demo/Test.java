package com.demo;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		/*Stream<String> stream=Stream.of("A","B","C").filter(e->e.contains("B"));
		Optional<String> findAny=stream.findAny();
		System.out.println(findAny.get());
		
		Optional<String> findFirst=stream.findFirst();*/
		
		List<String> collect=Stream.of("A","B","C").filter(e->e.contains("B")).collect(Collectors.toList());
		Optional<String> findAny=collect.stream().findAny();
		System.out.println(findAny.get());
		
		Optional<String> findFirst=collect.stream().findFirst();
		System.out.println(findFirst.get());
		
		
	}

}
