package com.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.demo.Student;

public class ClientTest {

	public static void main(String[] args) {
		List<Student> list=new ArrayList<>();
		list.add(new Student("Bindu",36));
		list.add(new Student("Yashu",26));
		list.add(new Student("Ranju",21));
		
		Stream<Student> filter=list.stream().filter(s->s.getAge()>25);
		filter.forEach(System.out::println);
		
		boolean allmatch=list.stream().allMatch(s->s.getName().contains("B"));
		System.out.println(allmatch);
		
		boolean anymatch=list.stream().anyMatch(s->s.getAge()>35);
		System.out.println(anymatch);
		
		boolean nonematch=list.stream().allMatch(s->s.getAge()>55);
		
		System.out.println(nonematch);

	}

}
