package com.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.model.Student;

public class ClientTest {
	public static void main(String[] args) {
		
	
	List<Student> list=new ArrayList<>();
	list.add(new Student("Bindu",22));
	list.add(new Student("Yashu",23));
	list.add(new Student("Ranju",21));
	
	Stream<Student> parallelStream=list.parallelStream();
	System.out.println("student data send for processing");
	parallelStream.forEach(s->doProcess(s));
}

	private static void doProcess(Student s) {
		
		System.out.println(s);
	}
}
