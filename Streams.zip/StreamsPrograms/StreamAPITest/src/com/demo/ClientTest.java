package com.demo;

import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {
		Stream build=Stream.builder().add("A").add("B").add("C").add(10).build();
		build.forEach(System.out::println);
		
		System.out.println("__________________");
		
		Stream<String> limit=Stream.generate(()->"Hello").limit(10);
		limit.forEach(System.out::println);
	}
	

}
