package com.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {
		List<String> list=new ArrayList<>();
		list.add("Bindu");
		list.add("Yashu");
		list.add("Ranju");
		/*Stream<String> stream=list.stream();
		Stream<String> distinct=stream.distinct();
		long count=distinct.count();
		*/
		
		long count=list.stream().distinct().distinct().count();
		System.out.println(count);
		
		
		
		boolean anyMatch=list.stream().anyMatch(s->s.contains("in"));
		System.out.println(anyMatch);
	}

}
