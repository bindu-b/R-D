package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Service;

import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.repository.ProductRepository;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

@Service
public class ProductService {
	/*@Autowired
	private ProductRepository prepo;
	
	public Product addProduct(String pname, String pcategory, double price, String pdesc, String uname, String uphone, String uemail) {
		return prepo.save(new Product(pname,pcategory,price,pdesc,uname,uphone,uemail));
		
	}

	public Product findByPname(String pname) {
		// TODO Auto-generated method stub
		return prepo.findByPname(pname);
	}
	
	public List<Product> findByPcategory(String electronics) {
		// TODO Auto-generated method stub
		return prepo.findByPcategory(electronics);
	}*/

	@Autowired
	private ProductRepository prepo;
	
	public Product addProduct(String pname, String pcategory, double price, String pdesc, String uname, String uphone, String uemail) {
		return prepo.save(new Product(pname,pcategory,price,pdesc,uname,uphone,uemail));
		
	}
	
	public double findByPrice(double price)
	{
		//return prepo.findByPrice(price);
		
		Product pro=new Product("fans","Electronics and Appliances",3000,"Fan","bindu","9481151309","bindu@gmail.com");
		System.out.println(price);
		return pro.getPrice();
		
	}

	public  String findByPname(String pname) {
		//prepo.findByPname(pname);
		
		Product pro=new Product("fans","Electronics and Appliances",3000,"Fan","bindu","9481151309","bindu@gmail.com");
		System.out.println(pname);
		return pro.getPname();
	}
	
	public String findBypcategory(String electronics) {
		//return prepo.findByPcategory(electronics);
		
		Product pro=new Product("fans","Electronics and Appliances",3000,"Fan","bindu","9481151309","bindu@gmail.com");
		System.out.println(electronics);
		return pro.getPcategory();
		
	}
	public  String findByEmail(String email) {
		//prepo.findByPname(pname);
		
		Product pro=new Product("fans","Electronics and Appliances",3000,"Fan","bindu","9481151309","bindu@gmail.com");
		System.out.println(email);
		return pro.getUemail();
	}
	
	public  String findByUname(String uname) {
		//prepo.findByPname(pname);
		
		Product pro=new Product("fans","Electronics and Appliances",3000,"Fan","bindu","9481151309","bindu@gmail.com");
		System.out.println(uname);
		return pro.getUname();
	}

	public String findByUphone(String uphone) {
		Product pro=new Product("fans","Electronics and Appliances",3000,"Fan","bindu","9481151309","bindu@gmail.com");
		System.out.println(uphone);
		return pro.getUphone();
	}
}
