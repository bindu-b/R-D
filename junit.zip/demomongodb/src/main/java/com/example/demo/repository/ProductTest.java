package com.example.demo.repository;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Product;
import com.example.demo.service.ProductService;

public class ProductTest {
		
//	ProductTestImpl productTest=new ProductTestImpl();
	//ProductService p=new ProductService();
	//ProductTestImpl productTestImpl=new ProductTestImpl();
	
	
	
	@Test
	public void testfindBypname()
	{
		
		ProductService productService = new ProductService();
		String pname = "fans";
		assertEquals(pname,productService.findByPname("fans"));
		
		
	}
	
	@Test
	public void TestfindByPrice()
	{
		ProductService productService = new ProductService();
		double pname = 3000;
		assertEquals(pname,productService.findByPrice(3000),0);
		
	}
	@Test
	public void TestfindByEmail()
	{
		ProductService productService = new ProductService();
		String email="bindu@gmail.com";
		assertEquals(email,productService.findByEmail("bindu@gmail.com"));
	}
	@Test
	public void TestfindBypcategory()
	{
		ProductService productService = new ProductService();
		String pcategory="Electronics and Appliances";
		assertEquals(pcategory,productService.findBypcategory("Electronics and Appliances"));
	}
	@Test
	public void TestfindByUname()
	{
		ProductService productService = new ProductService();
		String uname="bindu";
		assertEquals(uname,productService.findByUname("bindu"));
	}
	@Test
	public void TestfindByUphone()
	{
		ProductService productService = new ProductService();
		String uphone="9481151309";
		assertEquals(uphone,productService.findByUphone("9481151309"));
	}
	
	
	
	
	
	
}
